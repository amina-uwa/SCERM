% Contents of AIR_SEA TOOLBOX, Version 2.0
% 8/9/99
%
%
% air_dens.m             966  08-09-99 12:14p air_dens.m
% albedo.m             1,009  08-09-99 11:49a albedo.m
% albedot1.mat         7,757  07-21-98  5:59p albedot1.mat
% as_consts.m          3,699  08-09-99 11:54a as_consts.m
% binave.m             1,209  08-09-99 11:50a binave.m
% blwhf.m              2,775  08-05-99  4:54p blwhf.m
% cdnlp.m              1,197  08-05-99  5:13p cdnlp.m
% cdntc.m              1,356  08-05-99  5:18p cdntc.m
% cdnve.m              1,418  08-05-99  5:26p cdnve.m
% cloudcor.m           2,418  08-05-99  5:24p cloudcor.m
% clskswr.m            2,244  08-05-99  5:25p clskswr.m
% cool_skin.m          7,331  08-09-99 11:46a cool_skin.m
% delq.m               1,059  08-09-99 11:34a delq.m
% ep.m                   852  08-09-99 12:12p ep.m
% greg2.m              1,511  08-09-99 11:35a greg2.m
% hfbulktc.m          12,232  08-09-99 11:39a hfbulktc.m
% hms2h.m                714  08-09-99 11:39a hms2h.m
% julianmd.m           1,534  08-09-99 11:47a julianmd.m
% lfhf.m               1,626  08-09-99 11:47a lwhf.m
% no_skin_out.txt     13,953  08-05-99  3:41p no_skin_out.txt
% omegalmc.m           1,021  08-09-99 11:40a omegalmc.m
% qsat.m               1,329  08-09-99 11:52a qsat.m
% rain_flux.m          2,569  08-05-99  3:47p rain_flux.m
% readme.m             8,114  08-09-99  2:06p readme.m
% reedcf.m             3,807  08-05-99  3:50p reedcf.m
% relhumid.m           1,519  08-09-99 11:52a relhumid.m
% rhadj.m                707  08-05-99  3:53p rhadj.m
% satvap.m               785  08-09-99 11:42a satvap.m
% s2hms.m                478  08-05-99  3:53p s2hms.m
% slhftc.m             2,031  08-09-99 11:56a slhftc.m
% soradna1.m           4,486  08-09-99 11:42a soradna1.m
% spshftlp.m             993  08-09-99 11:43a spshftlp.m
% spshfttc.m           1,118  08-09-99 11:43a spshfttc.m
% spshftve.m             991  08-09-99 11:43a spshftve.m
% stresstc.m           1,061  08-09-99 11:57a stresstc.m
% stresslp.m             990  08-09-99 11:56a stresslp.m
% stressve.m             974  08-09-99 11:57a stressve.m
% sunrise.m            1,821  08-09-99 11:58a sunrise.m
% swhf.m               1,418  08-05-99  4:19p swhf.m
% t_hfbulktc.m         1,704  08-05-99  4:45p t_hfbulktc.m
% test2_5b.dat        11,699  08-05-99  4:20p test2_5b.dat
% vapor.m              1,019  08-09-99 11:44a vapor.m
% viscair.m              569  08-05-99  4:33p viscair.m
% wavdist2.m             876  08-05-99  4:37p wavdist2.m
% wavdist1.m           1,432  08-05-99  4:35p wavdist1.m
% wavdist.m            1,517  08-05-99  4:39p wavedist.m
% wdnotes.m            1,745  08-05-99  4:42p wdnotes.m
% yearday.m            1,162  08-05-99  4:43p yearday.m
% yes_skin_out.txt    13,958  08-05-99  4:43p yes_skin_out.txt



